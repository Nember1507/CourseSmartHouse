package com.example.coursesmarthouse;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.example.coursesmarthouse.databinding.FragmentPagerBinding;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;
import java.util.List;

public class PagerFragment extends Fragment {

    FragmentPagerBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_pager,container,false);

        return  binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        List<Fragment> fragmentList = new ArrayList<>();
        SwipeFragment fragment1 = SwipeFragment.newInstance("Fragment 1");
        SwipeFragment fragment2 = SwipeFragment.newInstance("Fragment 2");
        SwipeFragment fragment3 = SwipeFragment.newInstance("Fragment 3");
        SwipeFragment fragment4 = SwipeFragment.newInstance("Fragment 4");
        fragmentList.add(fragment1);
        fragmentList.add(fragment2);
        fragmentList.add(fragment3);
        fragmentList.add(fragment4);

        PagerAdapter adapter = new PagerAdapter((MainActivity) requireActivity(),fragmentList);
        binding.viewPager.setAdapter(adapter);

        new TabLayoutMediator(binding.tabLayout,binding.viewPager,(
                (tab, position) -> tab.setText("TAB"+(position+1))
                )).attach();

    }
}
