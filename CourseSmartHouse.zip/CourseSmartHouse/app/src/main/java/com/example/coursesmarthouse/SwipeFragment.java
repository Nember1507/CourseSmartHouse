package com.example.coursesmarthouse;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.example.coursesmarthouse.databinding.FragmentSwipeBinding;

public class SwipeFragment extends Fragment {

    FragmentSwipeBinding binding;

    public static SwipeFragment newInstance(String text){
        Bundle bundle = new Bundle();
        bundle.putString("text",text);
        SwipeFragment fragment = new SwipeFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_swipe,container,false);

        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.setText(getArguments().getString("text"));
    }
}
